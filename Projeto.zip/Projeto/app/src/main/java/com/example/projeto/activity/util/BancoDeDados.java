package com.example.projeto.activity.util;

public class BancoDeDados {
}
