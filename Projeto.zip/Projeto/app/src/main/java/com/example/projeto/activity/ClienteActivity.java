package com.example.projeto.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.projeto.R;

public class ClienteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cliente);
    }
}