package com.example.projeto.activity;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import com.example.projeto.R;

import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

public class LoginActivity extends AppCompatActivity {

    private TextView editCpfLogar, editSenhaLogar, botaoAjuda;
    private Button btnEntrar;
    private final String URL = "https://api.whatsapp.com/send/?phone=5581986271986&text&type=phone_number&app_absent=0";

    public String HOST = "http://192.168.31.75/Login";
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        inicializarComponentes();

        botaoAjuda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(URL) ));
            }
        });


        btnEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String cpf = editCpfLogar.getText().toString();
                String senha = editSenhaLogar.getText().toString();

                String URL = HOST + "/login.php";

                if(cpf.isEmpty() || senha.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Todos os campos são obrigatórios. ", Toast.LENGTH_LONG).show();
                } else{
                    Ion.with(LoginActivity.this)
                            .load(URL)
                            .setBodyParameter("cpf_app", cpf)
                            .setBodyParameter("senha_app", senha)
                            .asJsonObject()
                            .setCallback(new FutureCallback<JsonObject>() {
                                @Override
                                public void onCompleted(Exception e, JsonObject result) {

                                    try {
                                        String RETORNO = result.get("LOGIN").getAsString();

                                        if(RETORNO.equals("ERRO")){
                                            Toast.makeText(LoginActivity.this, "Ops! Email ou senha incorretos", Toast.LENGTH_SHORT).show();

                                        } else if(RETORNO.equals("SUCESSO")){
                                            Intent AbreTelaCliente = new Intent(LoginActivity.this, ClienteActivity.class);
                                            startActivity(AbreTelaCliente);
                                        } else {
                                            Toast.makeText(LoginActivity.this, "Ops! Ocorreu um erro", Toast.LENGTH_LONG).show();
                                        }

                                    } catch (Exception erro){
                                        Toast.makeText(LoginActivity.this, "Ops! Ocorreu um erro", Toast.LENGTH_LONG).show();
                                    }

                                }
                            });

                }
                    

            }
        });

    }


    private void inicializarComponentes(){

        editCpfLogar = (EditText) findViewById(R.id.editTextCpf);
        editSenhaLogar = (EditText) findViewById(R.id.editTextSenha);
        btnEntrar = (Button) findViewById(R.id.btnEntrar);
        botaoAjuda = (TextView) findViewById(R.id.button_ajuda);

    }



    }
